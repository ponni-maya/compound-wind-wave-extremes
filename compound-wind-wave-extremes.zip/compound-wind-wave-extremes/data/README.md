Place the input clustered CSVs here (see main project README for required
filenames and columns). Not included in version control due to size and
institutional data-sharing restrictions.
